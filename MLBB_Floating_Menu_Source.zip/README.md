# MLBB Floating Menu (UI overlay)

Project Android Kotlin untuk membuat gelembung mengambang dan panel menu yang bisa dipindah,
dibuka/tutup, serta tab PLAYER / MONSTER / ROOM / MISC.

PENTING: Ini adalah overlay UI yang berfungsi. Opsi di dalam panel hanya mengubah/menampilkan
kontrol UI; aplikasi ini tidak membaca memori, posisi musuh, data room, atau proses MLBB.

## Build
1. Buka folder ini di Android Studio atau AndroidIDE yang mendukung Gradle.
2. Tunggu Gradle sync selesai.
3. Build > Build APK(s).
4. Pasang APK hasil build.
5. Buka aplikasi, tekan AKTIFKAN FLOATING MENU, lalu izinkan "Tampil di atas aplikasi lain".
6. Ketuk gelembung J untuk membuka panel. Geser gelembung untuk memindahkannya.
7. Untuk mematikan, buka aplikasi lagi dan tekan MATIKAN MENU; atau hentikan layanan dari pengaturan aplikasi.

Target SDK 35; gunakan JDK 17 dan Android Gradle Plugin 8.7.3.
