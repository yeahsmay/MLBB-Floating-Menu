package com.jaccksallas.floatingmenu

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable

class FloatingMenuService : Service() {
    companion object {
        const val ACTION_START = "com.jaccksallas.floatingmenu.START"
        private const val CHANNEL = "floating_menu"
        private const val NOTIFICATION_ID = 41
    }

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var expanded = false
    private var activeTab = "PLAYER"

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Floating Menu aktif")
            .setContentText("Ketuk gelembung untuk membuka panel.")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        startForeground(NOTIFICATION_ID, notification)
        showBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun overlayParams(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(
            width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 220 }
    }

    private fun bg(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "J"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            background = bg(Color.rgb(53, 224, 193), 100f)
            setOnClickListener { if (expanded) hidePanel() else showPanel() }
        }
        var sx = 0; var sy = 0; var ox = 0; var oy = 0
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX.toInt(); sy = e.rawY.toInt()
                    val p = bubble?.layoutParams as? WindowManager.LayoutParams
                    ox = p?.x ?: 24; oy = p?.y ?: 220
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val p = bubble?.layoutParams as? WindowManager.LayoutParams
                    if (p != null) {
                        p.x = ox + e.rawX.toInt() - sx
                        p.y = oy + e.rawY.toInt() - sy
                        wm.updateViewLayout(b, p)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (kotlin.math.abs(e.rawX.toInt() - sx) < 8 &&
                        kotlin.math.abs(e.rawY.toInt() - sy) < 8) {
                        if (expanded) hidePanel() else showPanel()
                    }
                    true
                }
                else -> false
            }
        }
        bubble = b
        wm.addView(b, overlayParams(54, 54))
    }

    private fun showPanel() {
        if (panel != null) return
        expanded = true
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 12)
            background = bg(Color.rgb(20, 24, 35), 22f)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "JACKCSALLAS MENU"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(53, 224, 193))
        }
        val close = TextView(this).apply {
            text = "  ✕  "
            textSize = 18f
            setTextColor(Color.WHITE)
            setOnClickListener { hidePanel() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(close)
        root.addView(header)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("PLAYER", "MONSTER", "ROOM", "MISC").forEach { tab ->
            val t = TextView(this).apply {
                text = tab
                textSize = 10f
                gravity = Gravity.CENTER
                setPadding(7, 12, 7, 12)
                setTextColor(if (tab == activeTab) Color.rgb(53,224,193) else Color.LTGRAY)
                setOnClickListener { activeTab = tab; refreshPanel() }
            }
            tabs.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(tabs)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            tag = "body"
        }
        root.addView(body)
        addOptions(body)
        val footer = TextView(this).apply {
            text = "UI OVERLAY • MLBB MEMORY: NOT ACCESSED"
            textSize = 9f
            setTextColor(Color.GRAY)
            setPadding(0, 12, 0, 0)
        }
        root.addView(footer)
        panel = root
        wm.addView(root, overlayParams(290, WindowManager.LayoutParams.WRAP_CONTENT))
    }

    private fun addOptions(body: LinearLayout) {
        body.removeAllViews()
        val options = when (activeTab) {
            "PLAYER" -> listOf("Show panel label", "Show status indicator", "Compact layout")
            "MONSTER" -> listOf("Show section", "Show timer placeholder")
            "ROOM" -> listOf("Show room section", "Show room status")
            else -> listOf("Remember menu position", "Reduce panel opacity", "Always show bubble")
        }
        options.forEach { name ->
            val cb = CheckBox(this).apply {
                text = name
                textSize = 13f
                setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(53,224,193))
                isChecked = false
            }
            body.addView(cb)
        }
        val note = TextView(this).apply {
            text = "Pengaturan di sini hanya mengubah tampilan menu."
            textSize = 10f
            setTextColor(Color.LTGRAY)
            setPadding(2, 8, 2, 2)
        }
        body.addView(note)
    }

    private fun refreshPanel() {
        val root = panel as? LinearLayout ?: return
        val body = (0 until root.childCount).map { root.getChildAt(it) }
            .filterIsInstance<LinearLayout>().lastOrNull() ?: return
        addOptions(body)
        // Rebuild tab colors by refreshing the panel.
        hidePanel()
        showPanel()
    }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        expanded = false
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Floating Menu", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        hidePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
