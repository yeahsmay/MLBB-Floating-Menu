package com.jaccksallas.floatingmenu

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(16, 19, 27))
        }
        val title = TextView(this).apply {
            text = "JACKCSALLAS • FLOATING MENU"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Overlay menu Android. Tombol panel dan pengaturan UI berfungsi; aplikasi ini tidak membaca atau mengubah memori MLBB."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 22)
        }
        val start = Button(this).apply {
            text = "AKTIFKAN FLOATING MENU"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else {
                    val service = Intent(this@MainActivity, FloatingMenuService::class.java)
                        .setAction(FloatingMenuService.ACTION_START)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
                    finish()
                }
            }
        }
        val stop = Button(this).apply {
            text = "MATIKAN MENU"
            setOnClickListener {
                stopService(Intent(this@MainActivity, FloatingMenuService::class.java))
            }
        }
        root.addView(title)
        root.addView(info)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }
}
